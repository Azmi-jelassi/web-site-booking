{/*import React from "react";

const Carousel = () => {
  return (
    <div id="carouselExample" className="carousel slide" data-bs-ride="carousel">
      <div className="carousel-inner">
        <div className="carousel-item active">
          <img src="Image Placeholder (1).png" className="d-block w-50" alt="Slide 1" />
        </div>
        <div className="carousel-item">
          <img src="Image Placeholder (2).png" className="d-block w-50" alt="Slide 2" />
        </div>
        <div className="carousel-item">
          <img src="Image Placeholder (9).png" className="d-block w-50" alt="Slide 3" />
        </div>
      </div>
      <button className="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
        <span className="carousel-control-prev-icon" aria-hidden="true"></span>
      </button>
      <button className="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
        <span className="carousel-control-next-icon" aria-hidden="true"></span>
      </button>
    </div>
  );
};

export default Carousel;*/}
